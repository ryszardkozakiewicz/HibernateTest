create definer = root@localhost trigger fill_table
    after UPDATE
    on books
    for each row
BEGIN
INSERT IGNORE INTO to_order SELECT title FROM books WHERE books.on_stock =0 ;
END;

