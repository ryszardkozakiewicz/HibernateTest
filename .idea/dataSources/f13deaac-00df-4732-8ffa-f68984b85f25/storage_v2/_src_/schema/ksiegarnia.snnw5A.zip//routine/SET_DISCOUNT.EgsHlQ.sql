create
    definer = root@localhost procedure SET_DISCOUNT(IN x char(17), IN y int)
BEGIN
UPDATE books SET  price = price -( price* y/100) WHERE isbn = x;
END;

