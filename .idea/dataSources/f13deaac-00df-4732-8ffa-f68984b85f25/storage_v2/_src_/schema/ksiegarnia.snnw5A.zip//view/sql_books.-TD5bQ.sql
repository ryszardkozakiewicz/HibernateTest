create definer = root@localhost view sql_books as
select `ksiegarnia`.`books`.`title` AS `title`, `ksiegarnia`.`books`.`page_count` AS `page_count`
from `ksiegarnia`.`books`
where (`ksiegarnia`.`books`.`category` = 'bazy danych');

