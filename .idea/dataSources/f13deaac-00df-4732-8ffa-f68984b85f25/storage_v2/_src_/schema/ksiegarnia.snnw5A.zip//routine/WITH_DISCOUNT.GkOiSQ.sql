create
    definer = root@localhost function WITH_DISCOUNT(cena decimal(10, 2), percent int) returns decimal(10, 2)
BEGIN
RETURN cena - (cena * percent/100);
END;

